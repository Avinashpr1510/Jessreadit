# AuNP secondary analysis - reproducible script
# Reproduces all statistics and figures in the manuscript from the extracted dataset.
# Dependencies: python>=3.9, pandas, numpy, scipy, matplotlib
import pandas as pd, numpy as np, os
from scipy import stats
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

df = pd.read_csv('analysis_dataset.csv')   # the 12 extracted records (supplied)
print(df.describe())
print(df.groupby('family')['size_nm'].describe())

groups=[g['size_nm'].values for _,g in df.groupby('family')]
print('KW:', stats.kruskal(*groups))
c=df[df.family.str.startswith('Citrate')]['size_nm']; b=df[df.family.str.startswith('Brust')]['size_nm']
print('MW:', stats.mannwhitneyu(c,b))

rng=np.random.default_rng(42)
boots=[np.median(rng.choice(df['size_nm'],len(df),replace=True)) for _ in range(10000)]
print('Bootstrap 95% CI for median:', np.percentile(boots,[2.5,97.5]))

fig,ax=plt.subplots(figsize=(7.2,4.4))
ax.boxplot([df[df.family==f]['size_nm'].values for f in df.family.unique()],labels=df.family.unique())
ax.set_ylabel('Reported diameter (nm)'); plt.savefig('Figure2_reproduction.png',dpi=600); plt.close()
print('Done. Outputs: statistics above + Figure2_reproduction.png')
