README - AuNP secondary analysis package
========================================
Files:
  analysis.py           - full analysis pipeline (statistics + figure reproduction)
  analysis_dataset.csv  - the 12 extracted synthesis-size records with traceability tags

How to run:
  pip install pandas numpy scipy matplotlib
  python analysis.py

Expected outputs: console statistics (identical to Workbook 02, Sheet 6) and
Figure2_reproduction.png. Random seed fixed at 42 for the bootstrap.

Provenance: records were secondary-extracted on 2026-11-10 from
Ielo et al. 2021 (Molecules 26:5823, CC BY, doi:10.3390/molecules26195823).
See 06_Public_Data_Source_Register.xlsx for the full register.
No laboratory data exist in this package; no values were invented.
